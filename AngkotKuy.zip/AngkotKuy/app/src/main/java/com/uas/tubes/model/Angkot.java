package com.uas.tubes.model;

public class Angkot {
    public String judul;
    public String deskripsi;
    public String foto;
    public String detail;
    public Angkot(String judul, String deskripsi, String foto, String detail) {
        this.judul = judul;
        this.deskripsi = deskripsi;
        this.foto = foto;
        this.detail = detail;
    }
}
